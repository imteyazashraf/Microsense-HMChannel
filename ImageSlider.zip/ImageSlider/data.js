/**
 * Created by Mspl on 1/11/2018.
 */
module.exports = {
    routes: ['/'],
    props: {
        routes: {
            '/': {
                meta: {
                    title: 'Home page',
                },
            }
        },
        aliases: {},
    },
};
