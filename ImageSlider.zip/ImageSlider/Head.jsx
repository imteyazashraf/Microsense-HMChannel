var React = require('react');
var Carousel = require('nuka-carousel');
import $ from 'jquery'


'use strict';
const Head = React.createClass({
    render() {
        return(
            <h1> Header Working </h1>
        );
    }
});
module.exports = Head;