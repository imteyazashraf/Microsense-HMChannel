var React = require('react');
var Carousel = require('nuka-carousel');
import $ from 'jquery'


'use strict';
const App = React.createClass({

    mixins: [Carousel.ControllerMixin],
    slidesToScroll: React.PropTypes.oneOfType([
        React.PropTypes.number,
        React.PropTypes.oneOf(['auto'])
    ])
    ,
    render() {
        <Header />
            var xx = $(window).width() - 17;
            var yy = $(window).height()-77;
            return (

            <div>
                <div style={{height:"20px",fontWeight:"bold",paddingBottom:"0",color:"Red"}}><Header /></div>
                <div>
                <Carousel slidesToShow={1} width={xx} dynamicHeight={yy} speed={200} autoplay={true} autoplayInterval={3000} wrapAround = {true}>
                   {/* ref="carousel"
                    data={this.setCarouselData.bind(this, 'carousel')}
                    slideIndex={this.state.slideIndex}*/}
                    <img src="./Images/11.jpg" height={yy} aria-valuetext="1/2" />
                    <img src="./Images/1.jpg" height={yy} />
                    <img src="./Images/2.jpg" height={yy} />
                    <img src="./Images/3.jpg" height={yy} />
                    <img src="./Images/4.jpg" height={yy} />

                </Carousel>
                </div>
                <div style={{height:"15px",fontWeight:"bold",paddingBottom:"0",color:"Red"}}><Footer /></div>
            </div>
            );
        <Footer />
        }
});
module.exports = App;
class Header extends React.Component {
    /*getCurrentSlideText:function getCurrentSlideText() {
            var captionText = null;
                if ( this.setState({ slideIndex: 0 })) {

                    captionText = "Caption Text 1";
                    <p style={{
                        height: "15px",
                        fontWeight: "bold",
                        paddinng: "0 0 0 0",
                        textAlign: "cenntre"
                    }}>{captionText}</p>
                }
                else if (this.setState({ slideIndex: 1 })) {

                    captionText = "Caption Text 2";
                    <p style={{height: "15px", fontWeight: "bold", paddinng: "0 0 0 0"}}>{captionText}</p>
                }
                else if (this.setState({ slideIndex: 2 })) {

                    captionText = "Caption Text 3";
                    <p style={{height: "15px", fontWeight: "bold", paddinng: "0 0 0 0"}}>{captionText}</p>

                }
                else if (this.setState({ slideIndex: 3 })) {

                    captionText = "Caption Text 4";
                    <p style={{height: "15px", fontWeight: "bold", paddinng: "0 0 0 0"}}>{captionText}</p>

                }
                else if (this.setState({ slideIndex: 4 })) {

                    captionText = "Caption Text 4";
                    <p style={{height: "15px", fontWeight: "bold", paddinng: "0 0 0 0"}}>{captionText}</p>

                }
                else {
                    captionText = "Caption Text 5";
                    <p style={{height: "15px", fontWeight: "bold", paddinng: "0 0 0 0"}}>{captionText}</p>
                }
            }
        }
    //getCurrentSlideText();
    */
    render() {

        return (

            <p style={{height: "15px", fontWeight: "bold", paddinng: "0 0 0 0",textAlign:"center",textDecorationColor:"white"}}>1/5</p>
        );
    }
}

class Footer extends React.Component {

    render(){
        return (
                <p style={{height:"15px",fontWeight:"bold",paddinng:"0 0 0 0",textAlign:"center", textDecorationColor:"white"}}>Caption Text</p>
        );
    }
}