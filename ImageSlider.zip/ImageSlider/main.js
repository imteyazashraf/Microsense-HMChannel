import React from 'react';
import ReactDOM from 'react-dom';
import App from './App.jsx';

import $ from 'jquery';
ReactDOM.render(

        <App />, document.getElementById('app')
);