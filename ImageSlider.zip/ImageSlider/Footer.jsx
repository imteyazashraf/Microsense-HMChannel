var React = require('react');
var Carousel = require('nuka-carousel');
import $ from 'jquery'


'use strict';
const Footer = React.createClass({
    render() {
        return(
            < h4> Footer Working </h4>
        );
    }
});
module.exports = Footer;